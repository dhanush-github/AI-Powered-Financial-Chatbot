import pandas as pd

# Load sample financial data
df = pd.read_csv('financial_data.csv')

# Define chatbot function
def simple_chatbot(user_query):
    if user_query.lower() == "what is the total revenue?":
        return f"The total revenue is {df['Total Revenue'].iloc[-1]}."
    elif user_query.lower() == "how has net income changed over the last year?":
        change = df['Net Income'].pct_change().iloc[-1] * 100
        return f"The net income has {'increased' if change > 0 else 'decreased'} by {abs(change):.2f}% over the last year."
    else:
        return "Sorry, I can only provide information on predefined queries."

# Interactive chatbot
if __name__ == "__main__":
    print("Welcome to the financial chatbot! Ask a question or type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("Goodbye!")
            break
        response = simple_chatbot(user_input)
        print(f"Chatbot: {response}")
